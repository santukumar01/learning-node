//ceating a server using express

import express from 'express';
import ejsLayouts from 'express-ejs-layouts';
import ProductControllers from './src/controller/product.controller.js';
import path from "path";
import exp from 'constants';
import { validateMiddleware } from './src/middleware/validate.middleare.js';
const PORT = 3100;
const server = express();

server.use(express.static('public'));
// parse form data

server.use(express.urlencoded({ extended: true }));

// setup viwe engine
// informing server -> which server we are using
server.set("view engine", 'ejs');

// seting path for views
server.set('views', path.join(path.resolve(), 'src', 'view'))

// configure layout to use in middleware
// using layout

server.use(ejsLayouts);

// const pathmodule = path.join('src', 'view');
// server.use(express.static(pathmodule));

// server.get('/', (req, res) => {
//     res.send("Welcome to express server for invanttry app");
// })

//since this is method a we have to create a new instance for use 

const productControllers = new ProductControllers();

server.get('/', productControllers.getProducts)

server.get('/update-product/:id', productControllers.getUpdateProductview)

server.get('/new', productControllers.getAddForm);

server.get('/delete-product/:id', productControllers.deleteProduct)
// server.post('/delete-product/:id', productControllers.deleteProduct)

server.post('/', validateMiddleware, productControllers.getNewProduct);

server.post('/update-product/:id',
    productControllers.postUpdateProduct
)

server.listen(PORT, () => {
    console.log(`Our server is running on PORT : ${PORT}`);
})